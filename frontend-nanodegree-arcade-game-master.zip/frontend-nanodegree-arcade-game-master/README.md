
* The user plays as the princess.
* Use the directional arrow keys to move.
* Travel from the grass to the water while avoiding the incoming lady bugs.
* If you get hit the game and your score resets.
* Collecting any of the gems earns you an additional point.
* There is only one set of gems per life, they do not respawn.

